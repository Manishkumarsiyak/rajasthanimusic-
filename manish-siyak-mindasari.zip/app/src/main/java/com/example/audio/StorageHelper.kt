package com.example.audio

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Log
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.DecimalFormat

data class AudioFileInfo(
    val name: String,
    val sizeBytes: Long,
    val formattedSize: String,
    val durationMs: Long,
    val formattedDuration: String,
    val extension: String,
    val localFile: File,
    val isVideo: Boolean = false
)

object StorageHelper {
    private const val TAG = "StorageHelper"

    suspend fun copyUriToCache(context: Context, uri: Uri): AudioFileInfo? = withContext(Dispatchers.IO) {
        try {
            var fileName = "media_item.mp3"
            var fileSize: Long = 0

            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIndex != -1) {
                        fileName = cursor.getString(nameIndex) ?: fileName
                    }
                    if (sizeIndex != -1) {
                        fileSize = cursor.getLong(sizeIndex)
                    }
                }
            }

            val rawExt = fileName.substringAfterLast(".", "mp3").lowercase()
            val videoExtensions = listOf("mp4", "mkv", "mov", "3gp", "webm", "m4v")
            val isVideo = rawExt in videoExtensions

            val cacheDir = File(context.cacheDir, if (isVideo) "input_video" else "input_audio")
            if (!cacheDir.exists()) cacheDir.mkdirs()

            val sanitizedName = fileName.replace("[^a-zA-Z0-9._-]".toRegex(), "_")
            val tempFile = File(cacheDir, "input_${System.currentTimeMillis()}_$sanitizedName")
            
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                FileOutputStream(tempFile).use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
            }

            if (fileSize == 0L) {
                fileSize = tempFile.length()
            }

            var durationMs: Long = 0
            try {
                val mmr = MediaMetadataRetriever()
                mmr.setDataSource(tempFile.absolutePath)
                val durationStr = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                durationMs = durationStr?.toLongOrNull() ?: 0L
                mmr.release()
            } catch (e: Exception) {
                Log.w(TAG, "Could not extract duration with MMR", e)
            }

            AudioFileInfo(
                name = fileName,
                sizeBytes = fileSize,
                formattedSize = formatFileSize(fileSize),
                durationMs = durationMs,
                formattedDuration = formatDuration(durationMs),
                extension = rawExt.uppercase(),
                localFile = tempFile,
                isVideo = isVideo
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to copy media from URI: $uri", e)
            null
        }
    }

    suspend fun saveAudioExport(
        context: Context,
        sourceFile: File,
        originalName: String,
        targetDirectory: String = Environment.DIRECTORY_DOWNLOADS
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val baseName = originalName.substringBeforeLast(".")
            val targetName = "${baseName}_StudioSafeMod.mp3"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, targetName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "audio/mpeg")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, targetDirectory)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }

                val collection = if (targetDirectory == Environment.DIRECTORY_MUSIC) {
                    MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                } else {
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI
                }

                val itemUri = context.contentResolver.insert(collection, values)
                    ?: return@withContext Result.failure(Exception("Failed to create MediaStore entry"))

                context.contentResolver.openOutputStream(itemUri)?.use { output ->
                    FileInputStream(sourceFile).use { input ->
                        input.copyTo(output)
                    }
                }

                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                context.contentResolver.update(itemUri, values, null, null)

                val dirLabel = if (targetDirectory == Environment.DIRECTORY_MUSIC) "Music" else "Downloads"
                Result.success("Saved to $dirLabel: $targetName")
            } else {
                @Suppress("DEPRECATION")
                val publicDir = Environment.getExternalStoragePublicDirectory(targetDirectory)
                if (!publicDir.exists()) publicDir.mkdirs()
                val targetFile = File(publicDir, targetName)

                FileInputStream(sourceFile).use { input ->
                    FileOutputStream(targetFile).use { output ->
                        input.copyTo(output)
                    }
                }
                Result.success("Saved: ${targetFile.name}")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to export audio file", e)
            Result.failure(e)
        }
    }

    suspend fun saveVideoExport(
        context: Context,
        sourceFile: File,
        originalName: String,
        targetDirectory: String = Environment.DIRECTORY_MOVIES
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val baseName = originalName.substringBeforeLast(".")
            val targetName = "${baseName}_ShortSafe.mp4"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, targetName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, targetDirectory)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }

                val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                val itemUri = context.contentResolver.insert(collection, values)
                    ?: return@withContext Result.failure(Exception("Failed to create MediaStore video entry"))

                context.contentResolver.openOutputStream(itemUri)?.use { output ->
                    FileInputStream(sourceFile).use { input ->
                        input.copyTo(output)
                    }
                }

                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                context.contentResolver.update(itemUri, values, null, null)

                Result.success("Saved to Gallery/Movies: $targetName")
            } else {
                @Suppress("DEPRECATION")
                val publicDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
                if (!publicDir.exists()) publicDir.mkdirs()
                val targetFile = File(publicDir, targetName)

                FileInputStream(sourceFile).use { input ->
                    FileOutputStream(targetFile).use { output ->
                        input.copyTo(output)
                    }
                }
                Result.success("Saved: ${targetFile.name}")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to export video file", e)
            Result.failure(e)
        }
    }

    fun shareMedia(context: Context, file: File, isVideo: Boolean, title: String = "Share File") {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.provider",
                file
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = if (isVideo) "video/mp4" else "audio/mpeg"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, file.name)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            val chooser = Intent.createChooser(shareIntent, title)
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (e: Exception) {
            Log.e(TAG, "Error sharing media file", e)
        }
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
        val index = digitGroups.coerceIn(0, units.size - 1)
        val value = bytes / Math.pow(1024.0, index.toDouble())
        return DecimalFormat("#,##0.0#").format(value) + " " + units[index]
    }

    fun formatDuration(ms: Long): String {
        if (ms <= 0) return "--:--"
        val totalSeconds = ms / 1000
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return String.format(java.util.Locale.US, "%02d:%02d", minutes, seconds)
    }
}
