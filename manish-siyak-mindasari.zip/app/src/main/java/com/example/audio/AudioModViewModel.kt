package com.example.audio

import android.app.Application
import android.net.Uri
import android.os.Environment
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

data class SmartPreset(
    val id: String,
    val titleHindi: String,
    val titleEnglish: String,
    val description: String,
    val badge: String,
    val config: AdvancedDspConfig
)

val ADVANCED_PRESETS = listOf(
    SmartPreset(
        id = "natural_shield",
        titleHindi = "नेचुरल शील्ड",
        titleEnglish = "Natural Shield",
        description = "न्यूनतम बदलाव, 100% ओरिजिनल आवाज़ और मिठास। 5ms स्टीरियो फेज़ शिफ्ट + सूक्ष्म 1.012x पिच।",
        badge = "100% Original Tone",
        config = AdvancedDspConfig(
            presetId = "natural_shield",
            pitchMultiplier = 1.012f,
            tempoMultiplier = 1.00f,
            channelDelayMs = 5,
            subBassBoostDb = 0.5f,
            trebleAirBoostDb = 0.8f,
            midVocalCutDb = 0.0f,
            enableAmbientLayer = false,
            enableLoudnorm = true,
            stripMetadata = true,
            audioBitrate = "320k"
        )
    ),
    SmartPreset(
        id = "deep_wave",
        titleHindi = "डीप वेव मॉड",
        titleEnglish = "Deep Wave Mod",
        description = "फेज़ शिफ्ट (6ms) + डायनामिक EQ (+1dB सब-बेस, +1.2dB एयर) + -38dB एम्बिएंट शील्ड लेयर + लाउडनॉर्म।",
        badge = "Maximum Protection",
        config = AdvancedDspConfig(
            presetId = "deep_wave",
            pitchMultiplier = 1.020f,
            tempoMultiplier = 1.00f,
            channelDelayMs = 6,
            subBassBoostDb = 1.0f,
            trebleAirBoostDb = 1.2f,
            midVocalCutDb = 0.0f,
            enableAmbientLayer = true,
            enableLoudnorm = true,
            stripMetadata = true,
            audioBitrate = "320k"
        )
    ),
    SmartPreset(
        id = "bpm_shift",
        titleHindi = "बीपीएम शिफ्ट",
        titleEnglish = "BPM Shift",
        description = "सूक्ष्म टेम्पो 1.015x + पिच बैलेंस (1.015x) + 7ms स्टीरियो डिले + लाउडनेस नॉर्मलाइज़ेशन।",
        badge = "Rhythm Shift",
        config = AdvancedDspConfig(
            presetId = "bpm_shift",
            pitchMultiplier = 1.015f,
            tempoMultiplier = 1.015f,
            channelDelayMs = 7,
            subBassBoostDb = 1.0f,
            trebleAirBoostDb = 1.0f,
            midVocalCutDb = 0.0f,
            enableAmbientLayer = true,
            enableLoudnorm = true,
            stripMetadata = true,
            audioBitrate = "320k"
        )
    )
)

class AudioModViewModel(application: Application) : AndroidViewModel(application) {

    private val _selectedAudio = MutableStateFlow<AudioFileInfo?>(null)
    val selectedAudio: StateFlow<AudioFileInfo?> = _selectedAudio.asStateFlow()

    private val _processingState = MutableStateFlow<ProcessingState>(ProcessingState.Idle)
    val processingState: StateFlow<ProcessingState> = _processingState.asStateFlow()

    private val _selectedPresetIndex = MutableStateFlow(1) // Default to "Deep Wave Mod" (Mode 2)
    val selectedPresetIndex: StateFlow<Int> = _selectedPresetIndex.asStateFlow()

    // Custom Mode Sliders
    private val _customDelayMs = MutableStateFlow(6)
    val customDelayMs: StateFlow<Int> = _customDelayMs.asStateFlow()

    private val _customPitch = MutableStateFlow(1.020f)
    val customPitch: StateFlow<Float> = _customPitch.asStateFlow()

    private val _customBassBoost = MutableStateFlow(1.0f)
    val customBassBoost: StateFlow<Float> = _customBassBoost.asStateFlow()

    private val _customTrebleAir = MutableStateFlow(1.2f)
    val customTrebleAir: StateFlow<Float> = _customTrebleAir.asStateFlow()

    private val _customAmbientLayer = MutableStateFlow(true)
    val customAmbientLayer: StateFlow<Boolean> = _customAmbientLayer.asStateFlow()

    private val _customLoudnorm = MutableStateFlow(true)
    val customLoudnorm: StateFlow<Boolean> = _customLoudnorm.asStateFlow()

    private val _stripMetadata = MutableStateFlow(true)
    val stripMetadata: StateFlow<Boolean> = _stripMetadata.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    val playerManager = AudioPlayerManager(application.applicationContext, viewModelScope)
    val playerState: StateFlow<PlayerState> = playerManager.playerState

    fun onMediaSelected(uri: Uri) {
        viewModelScope.launch {
            _processingState.value = ProcessingState.Idle
            playerManager.release()
            val info = StorageHelper.copyUriToCache(getApplication(), uri)
            _selectedAudio.value = info
            if (info != null) {
                val mediaType = if (info.isVideo) "🎬 YouTube Short वीडियो" else "🎵 गाना / ऑडियो"
                _statusMessage.value = "चयनित: $mediaType - ${info.name}"
            } else {
                _statusMessage.value = "फ़ाइल लोड नहीं हो सकी"
            }
        }
    }

    fun setPresetIndex(index: Int) {
        _selectedPresetIndex.value = index
    }

    fun setCustomDelayMs(ms: Int) {
        _customDelayMs.value = ms
    }

    fun setCustomPitch(pitch: Float) {
        _customPitch.value = pitch
    }

    fun setCustomBassBoost(boost: Float) {
        _customBassBoost.value = boost
    }

    fun setCustomTrebleAir(air: Float) {
        _customTrebleAir.value = air
    }

    fun setCustomAmbientLayer(enable: Boolean) {
        _customAmbientLayer.value = enable
    }

    fun setCustomLoudnorm(enable: Boolean) {
        _customLoudnorm.value = enable
    }

    fun setStripMetadata(strip: Boolean) {
        _stripMetadata.value = strip
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun startProcessing() {
        val mediaInfo = _selectedAudio.value ?: return

        val config = if (_selectedPresetIndex.value < ADVANCED_PRESETS.size) {
            val preset = ADVANCED_PRESETS[_selectedPresetIndex.value]
            preset.config.copy(stripMetadata = _stripMetadata.value)
        } else {
            AdvancedDspConfig(
                presetId = "custom_pro",
                pitchMultiplier = _customPitch.value,
                tempoMultiplier = 1.00f,
                channelDelayMs = _customDelayMs.value,
                subBassBoostDb = _customBassBoost.value,
                trebleAirBoostDb = _customTrebleAir.value,
                midVocalCutDb = 0.0f,
                enableAmbientLayer = _customAmbientLayer.value,
                enableLoudnorm = _customLoudnorm.value,
                stripMetadata = _stripMetadata.value,
                audioBitrate = "320k"
            )
        }

        _processingState.value = ProcessingState.Processing(0, "प्रोटेक्शन इंजन शुरू हो रहा है...")
        playerManager.release()

        viewModelScope.launch {
            val result = if (mediaInfo.isVideo) {
                AudioProcessor.processVideoForShorts(
                    context = getApplication(),
                    inputFile = mediaInfo.localFile,
                    totalDurationMs = mediaInfo.durationMs,
                    config = config,
                    onProgress = { percent, stage, _ ->
                        _processingState.value = ProcessingState.Processing(
                            progressPercentage = percent,
                            stageMessage = stage
                        )
                    }
                )
            } else {
                AudioProcessor.processAudio(
                    context = getApplication(),
                    inputFile = mediaInfo.localFile,
                    totalDurationMs = mediaInfo.durationMs,
                    config = config,
                    onProgress = { percent, stage, _ ->
                        _processingState.value = ProcessingState.Processing(
                            progressPercentage = percent,
                            stageMessage = stage
                        )
                    }
                )
            }
            _processingState.value = result

            if (result is ProcessingState.Success) {
                // If it produced an audio track, load it into A/B player
                if (result.outputFile.exists() && result.outputFile.extension == "mp3") {
                    playerManager.setFiles(
                        original = mediaInfo.localFile,
                        modified = result.outputFile,
                        defaultTrack = AudioTrackType.MODIFIED
                    )
                }
                _statusMessage.value = if (result.isVideo) {
                    "✅ YouTube Shorts वीडियो तैयार है! अब बेफिक्र होकर अपलोड करें।"
                } else {
                    "✅ गाना सुरक्षित हो गया है! अब बेफिक्र होकर उपयोग करें।"
                }
            } else if (result is ProcessingState.Error) {
                _statusMessage.value = "प्रोसेसिंग विफल: ${result.message}"
            }
        }
    }

    fun exportAudio(saveToMusic: Boolean = false) {
        val currentState = _processingState.value
        val mediaInfo = _selectedAudio.value
        if (currentState is ProcessingState.Success && mediaInfo != null) {
            viewModelScope.launch {
                val targetDir = if (saveToMusic) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_DOWNLOADS
                val saveResult = StorageHelper.saveAudioExport(
                    context = getApplication(),
                    sourceFile = currentState.outputFile,
                    originalName = mediaInfo.name,
                    targetDirectory = targetDir
                )
                saveResult.onSuccess { msg ->
                    _statusMessage.value = msg
                }.onFailure { err ->
                    _statusMessage.value = "सेव नहीं हुआ: ${err.message}"
                }
            }
        }
    }

    fun exportVideo() {
        val currentState = _processingState.value
        val mediaInfo = _selectedAudio.value
        if (currentState is ProcessingState.Success && currentState.outputVideoFile != null && mediaInfo != null) {
            viewModelScope.launch {
                val saveResult = StorageHelper.saveVideoExport(
                    context = getApplication(),
                    sourceFile = currentState.outputVideoFile,
                    originalName = mediaInfo.name
                )
                saveResult.onSuccess { msg ->
                    _statusMessage.value = msg
                }.onFailure { err ->
                    _statusMessage.value = "वीडियो सेव नहीं हुआ: ${err.message}"
                }
            }
        }
    }

    fun shareMedia(isVideo: Boolean = false) {
        val currentState = _processingState.value
        if (currentState is ProcessingState.Success) {
            val fileToShare = if (isVideo && currentState.outputVideoFile != null) {
                currentState.outputVideoFile
            } else {
                currentState.outputFile
            }
            StorageHelper.shareMedia(
                context = getApplication(),
                file = fileToShare,
                isVideo = isVideo,
                title = if (isVideo) "Share YouTube Short Video" else "Share Audio"
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        playerManager.release()
    }
}
