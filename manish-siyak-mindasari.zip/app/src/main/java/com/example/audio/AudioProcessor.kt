package com.example.audio

import android.content.Context
import android.util.Log
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.ReturnCode
import com.arthenica.ffmpegkit.Statistics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume

data class AdvancedDspConfig(
    val presetId: String = "deep_wave",
    val pitchMultiplier: Float = 1.02f,
    val tempoMultiplier: Float = 1.00f,
    val channelDelayMs: Int = 6, // 5 to 8 ms micro phase/stereo shift
    val subBassBoostDb: Float = 1.0f, // 60Hz - 150Hz +1dB
    val trebleAirBoostDb: Float = 1.2f, // 10kHz - 14kHz +1.2dB
    val midVocalCutDb: Float = 0.0f, // Vocals kept clean & untouched
    val enableAmbientLayer: Boolean = true, // -38dB inaudible ambient layer to break hash codes
    val enableLoudnorm: Boolean = true, // studio broadcast loudness normalization
    val stripMetadata: Boolean = true,
    val audioBitrate: String = "320k"
)

sealed class ProcessingState {
    object Idle : ProcessingState()
    data class Processing(
        val progressPercentage: Int = 0,
        val stageMessage: String = "Initializing Audio DSP Engine...",
        val currentSeconds: Double = 0.0
    ) : ProcessingState()
    data class Success(
        val outputFile: File,
        val outputVideoFile: File? = null,
        val isVideo: Boolean = false,
        val timeTakenMs: Long,
        val presetName: String
    ) : ProcessingState()
    data class Error(
        val message: String,
        val detailedLog: String = ""
    ) : ProcessingState()
}

object AudioProcessor {
    private const val TAG = "AudioProcessor"

    suspend fun processAudio(
        context: Context,
        inputFile: File,
        totalDurationMs: Long,
        config: AdvancedDspConfig,
        onProgress: (Int, String, Double) -> Unit = { _, _, _ -> }
    ): ProcessingState = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val outputDir = File(context.cacheDir, "processed_audio")
        if (!outputDir.exists()) outputDir.mkdirs()

        val outputFileName = "SafeMod_${System.currentTimeMillis()}.mp3"
        val outputFile = File(outputDir, outputFileName)
        if (outputFile.exists()) outputFile.delete()

        val standardAfChain = buildStandardAfChain(config)
        val metadataOption = if (config.stripMetadata) "-map_metadata -1" else ""

        val command = if (config.enableAmbientLayer) {
            val preMixChain = buildPreMixChain(config)
            val postLoudnorm = if (config.enableLoudnorm) ",loudnorm=I=-14:TP=-1.5:LRA=11" else ""
            "-y -i \"${inputFile.absolutePath}\" -filter_complex \"[0:a]$preMixChain[main];anoisesrc=c=pink:r=44100:a=0.004[noise];[main][noise]amix=inputs=2:duration=first:dropout_transition=0$postLoudnorm[out]\" -map \"[out]\" $metadataOption -c:a libmp3lame -b:a ${config.audioBitrate} \"${outputFile.absolutePath}\""
        } else {
            "-y -i \"${inputFile.absolutePath}\" -af \"$standardAfChain\" $metadataOption -c:a libmp3lame -b:a ${config.audioBitrate} \"${outputFile.absolutePath}\""
        }

        Log.d(TAG, "Executing FFmpeg DSP command: $command")
        onProgress(5, "Initializing DSP Audio Pipeline...", 0.0)

        val result = executeFFmpegWithProgress(
            command = command,
            totalDurationMs = totalDurationMs,
            onProgress = onProgress
        )

        // Automatic fallback to standard chain if ambient complex graph fails
        if (!result.isSuccess && config.enableAmbientLayer) {
            Log.w(TAG, "Falling back to robust multi-band filter chain...")
            onProgress(15, "Engaging Multi-Band Safe DSP Pipeline...", 0.0)
            val fallbackCommand = "-y -i \"${inputFile.absolutePath}\" -af \"$standardAfChain\" $metadataOption -c:a libmp3lame -b:a ${config.audioBitrate} \"${outputFile.absolutePath}\""
            val fallbackResult = executeFFmpegWithProgress(
                command = fallbackCommand,
                totalDurationMs = totalDurationMs,
                onProgress = onProgress
            )
            if (fallbackResult.isSuccess && outputFile.exists()) {
                val timeTaken = System.currentTimeMillis() - startTime
                onProgress(100, "Processing complete!", totalDurationMs / 1000.0)
                return@withContext ProcessingState.Success(
                    outputFile = outputFile,
                    timeTakenMs = timeTaken,
                    presetName = config.presetId
                )
            } else {
                return@withContext ProcessingState.Error(
                    message = "Audio processing failed: ${fallbackResult.errorMessage}",
                    detailedLog = fallbackResult.logs
                )
            }
        }

        if (result.isSuccess && outputFile.exists()) {
            val timeTaken = System.currentTimeMillis() - startTime
            onProgress(100, "Processing complete!", totalDurationMs / 1000.0)
            ProcessingState.Success(
                outputFile = outputFile,
                timeTakenMs = timeTaken,
                presetName = config.presetId
            )
        } else {
            ProcessingState.Error(
                message = "DSP processing failed: ${result.errorMessage}",
                detailedLog = result.logs
            )
        }
    }

    suspend fun processVideoForShorts(
        context: Context,
        inputFile: File,
        totalDurationMs: Long,
        config: AdvancedDspConfig,
        onProgress: (Int, String, Double) -> Unit = { _, _, _ -> }
    ): ProcessingState = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val outputDir = File(context.cacheDir, "processed_shorts")
        if (!outputDir.exists()) outputDir.mkdirs()

        val outputVideoName = "SafeShort_${System.currentTimeMillis()}.mp4"
        val outputAudioName = "SafeAudio_${System.currentTimeMillis()}.mp3"
        val outputVideoFile = File(outputDir, outputVideoName)
        val outputAudioFile = File(outputDir, outputAudioName)

        val standardAfChain = buildStandardAfChain(config)
        val metadataOption = if (config.stripMetadata) "-map_metadata -1" else ""

        // Process video: Copy video frames untouched (-c:v copy), modify audio stream with Safe DSP
        val videoCommand = "-y -i \"${inputFile.absolutePath}\" -c:v copy -af \"$standardAfChain\" -c:a aac -b:a 320k $metadataOption \"${outputVideoFile.absolutePath}\""

        Log.d(TAG, "Executing Shorts Video DSP command: $videoCommand")
        onProgress(10, "Processing YouTube Short Video Audio Shield...", 0.0)

        val result = executeFFmpegWithProgress(
            command = videoCommand,
            totalDurationMs = totalDurationMs,
            onProgress = onProgress
        )

        if (result.isSuccess && outputVideoFile.exists()) {
            // Also extract an audio MP3 track for convenience
            val extractAudioCommand = "-y -i \"${outputVideoFile.absolutePath}\" -vn -c:a libmp3lame -b:a 320k \"${outputAudioFile.absolutePath}\""
            FFmpegKit.execute(extractAudioCommand)

            val timeTaken = System.currentTimeMillis() - startTime
            onProgress(100, "YouTube Short ready to upload!", totalDurationMs / 1000.0)
            ProcessingState.Success(
                outputFile = if (outputAudioFile.exists()) outputAudioFile else outputVideoFile,
                outputVideoFile = outputVideoFile,
                isVideo = true,
                timeTakenMs = timeTaken,
                presetName = config.presetId
            )
        } else {
            ProcessingState.Error(
                message = "Video DSP processing failed: ${result.errorMessage}",
                detailedLog = result.logs
            )
        }
    }

    private fun buildStandardAfChain(config: AdvancedDspConfig): String {
        val targetSampleRate = 44100
        val calculatedRate = (targetSampleRate * config.pitchMultiplier).toInt()

        val stereoDelayFilter = "aformat=channel_layouts=stereo,adelay=${config.channelDelayMs}|0"
        val bassFilter = if (config.subBassBoostDb != 0f) "equalizer=f=90:t=q:w=1:g=${String.format(java.util.Locale.US, "%.1f", config.subBassBoostDb)}" else ""
        val vocalFilter = if (config.midVocalCutDb != 0f) "equalizer=f=1000:t=q:w=1:g=${String.format(java.util.Locale.US, "%.1f", config.midVocalCutDb)}" else ""
        val trebleFilter = if (config.trebleAirBoostDb != 0f) "equalizer=f=12000:t=q:w=1:g=${String.format(java.util.Locale.US, "%.1f", config.trebleAirBoostDb)}" else ""

        val eqComponents = listOf(bassFilter, vocalFilter, trebleFilter).filter { it.isNotEmpty() }
        val eqFilterChain = if (eqComponents.isNotEmpty()) eqComponents.joinToString(",") else ""

        val pitchFilter = "asetrate=$calculatedRate,aresample=$targetSampleRate,atempo=${String.format(java.util.Locale.US, "%.3f", config.tempoMultiplier)}"
        val loudnormFilter = if (config.enableLoudnorm) "loudnorm=I=-14:TP=-1.5:LRA=11" else ""

        val afList = mutableListOf<String>()
        afList.add(stereoDelayFilter)
        afList.add(pitchFilter)
        if (eqFilterChain.isNotEmpty()) afList.add(eqFilterChain)
        if (loudnormFilter.isNotEmpty()) afList.add(loudnormFilter)
        return afList.joinToString(",")
    }

    private fun buildPreMixChain(config: AdvancedDspConfig): String {
        val targetSampleRate = 44100
        val calculatedRate = (targetSampleRate * config.pitchMultiplier).toInt()
        val stereoDelayFilter = "aformat=channel_layouts=stereo,adelay=${config.channelDelayMs}|0"
        val bassFilter = if (config.subBassBoostDb != 0f) "equalizer=f=90:t=q:w=1:g=${String.format(java.util.Locale.US, "%.1f", config.subBassBoostDb)}" else ""
        val trebleFilter = if (config.trebleAirBoostDb != 0f) "equalizer=f=12000:t=q:w=1:g=${String.format(java.util.Locale.US, "%.1f", config.trebleAirBoostDb)}" else ""

        val eqComponents = listOf(bassFilter, trebleFilter).filter { it.isNotEmpty() }
        val eqFilterChain = if (eqComponents.isNotEmpty()) eqComponents.joinToString(",") else ""
        val pitchFilter = "asetrate=$calculatedRate,aresample=$targetSampleRate,atempo=${String.format(java.util.Locale.US, "%.3f", config.tempoMultiplier)}"

        val list = mutableListOf(stereoDelayFilter, pitchFilter)
        if (eqFilterChain.isNotEmpty()) list.add(eqFilterChain)
        return list.joinToString(",")
    }

    private data class ExecutionResult(
        val isSuccess: Boolean,
        val errorMessage: String = "",
        val logs: String = ""
    )

    private suspend fun executeFFmpegWithProgress(
        command: String,
        totalDurationMs: Long,
        onProgress: (Int, String, Double) -> Unit
    ): ExecutionResult = suspendCancellableCoroutine { continuation ->
        var lastPercentage = 5

        FFmpegKit.executeAsync(
            command,
            { session: FFmpegSession ->
                val returnCode = session.returnCode
                if (ReturnCode.isSuccess(returnCode)) {
                    if (continuation.isActive) {
                        continuation.resume(ExecutionResult(isSuccess = true))
                    }
                } else {
                    val logs = session.allLogsAsString ?: "Execution failed"
                    if (continuation.isActive) {
                        continuation.resume(
                            ExecutionResult(
                                isSuccess = false,
                                errorMessage = "Exit code ${returnCode?.value ?: -1}",
                                logs = logs.takeLast(1000)
                            )
                        )
                    }
                }
            },
            { log ->
                val msg = log.message ?: ""
                if (msg.contains("loudnorm", ignoreCase = true)) {
                    onProgress(lastPercentage, "Normalizing broadcast studio loudness...", 0.0)
                }
            },
            { stats: Statistics ->
                val processedMs = stats.time
                val processedSec = processedMs / 1000.0
                if (totalDurationMs > 0) {
                    val percent = ((processedMs.toDouble() / totalDurationMs.toDouble()) * 100).toInt().coerceIn(5, 98)
                    lastPercentage = percent
                    val stage = when {
                        percent < 25 -> "Stage 1/4: Stereo Phase Delay & Resampling (${percent}%)"
                        percent < 55 -> "Stage 2/4: Multi-Band Dynamic EQ (${percent}%)"
                        percent < 80 -> "Stage 3/4: Micro Acoustic Inaudible Shield (${percent}%)"
                        else -> "Stage 4/4: Loudnorm Broadcast Master (${percent}%)"
                    }
                    onProgress(percent, stage, processedSec)
                } else {
                    val fallbackPercent = (lastPercentage + 4).coerceAtMost(95)
                    lastPercentage = fallbackPercent
                    onProgress(fallbackPercent, "Processing DSP: ${String.format(java.util.Locale.US, "%.1f", processedSec)}s", processedSec)
                }
            }
        )
    }
}
