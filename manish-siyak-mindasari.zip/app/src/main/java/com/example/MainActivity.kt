package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.audio.AudioFileInfo
import com.example.audio.AudioModViewModel
import com.example.audio.AudioTrackType
import com.example.audio.PlayerState
import com.example.audio.ProcessingState
import com.example.audio.StorageHelper
import com.example.ui.theme.AccentError
import com.example.ui.theme.AccentSuccess
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldTertiary
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.StudioCardBg
import com.example.ui.theme.StudioDarkBg
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

class MainActivity : ComponentActivity() {

    private val viewModel: AudioModViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                EasyStudioDashboard(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EasyStudioDashboard(viewModel: AudioModViewModel) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    val selectedAudio by viewModel.selectedAudio.collectAsState()
    val processingState by viewModel.processingState.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()
    val playerState by viewModel.playerState.collectAsState()

    var showAdvancedSettings by remember { mutableStateOf(false) }

    // File Pickers for Audio and Video
    val mediaPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            viewModel.onMediaSelected(uri)
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val anyGranted = permissions.values.any { it }
        if (anyGranted) {
            mediaPickerLauncher.launch("*/*")
        } else {
            Toast.makeText(context, "मीडिया चुनने के लिए परमिशन ज़रूरी है", Toast.LENGTH_SHORT).show()
        }
    }

    fun launchMediaPicker(mimeType: String) {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (mimeType.startsWith("video")) {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) {
                    permissions.add(Manifest.permission.READ_MEDIA_VIDEO)
                }
            } else {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    permissions.add(Manifest.permission.READ_MEDIA_AUDIO)
                }
            }
        } else {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }

        if (permissions.isEmpty()) {
            mediaPickerLauncher.launch(mimeType)
        } else {
            try {
                permissionLauncher.launch(permissions.toTypedArray())
            } catch (e: Exception) {
                mediaPickerLauncher.launch(mimeType)
            }
        }
    }

    LaunchedEffect(statusMessage) {
        statusMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearStatusMessage()
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // User's custom photo logo badge with golden aura ring
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(Color(0xFFFFD700), CyanPrimary)))
                                .padding(2.dp)
                                .clip(CircleShape)
                                .background(StudioDarkBg),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_user_leader_logo),
                                contentDescription = "MANISH SIYAK Logo",
                                modifier = Modifier.size(38.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "MANISH SIYAK MINDASARI",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "YouTube Shorts & Songs Safe Shield",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyanSecondary
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(EmeraldTertiary.copy(alpha = 0.2f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "VERIFIED SAFE",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldTertiary
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = StudioDarkBg)
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = StudioDarkBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 10.dp)
                .widthIn(max = 640.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {

            // Step 1: मीडिया चुनें (Select Song OR YouTube Shorts Video)
            EasySongInputCard(
                selectedAudio = selectedAudio,
                onSelectAudioClick = { launchMediaPicker("audio/*") },
                onSelectVideoClick = { launchMediaPicker("video/*") }
            )

            // Step 2: 1-Click Action & Live Percentage Progress Bar
            OneClickProcessCard(
                selectedAudio = selectedAudio,
                processingState = processingState,
                onStartProcessing = { viewModel.startProcessing() }
            )

            // Step 3: तैयार है (A/B Player & Direct Export)
            AnimatedVisibility(
                visible = processingState is ProcessingState.Success,
                enter = fadeIn() + slideInVertically()
            ) {
                if (processingState is ProcessingState.Success) {
                    val success = processingState as ProcessingState.Success
                    EasyReadyExportCard(
                        success = success,
                        playerState = playerState,
                        onPlayPause = { viewModel.playerManager.togglePlayPause() },
                        onSeek = { viewModel.playerManager.seekTo(it) },
                        onSwitchTrack = { viewModel.playerManager.switchTrack(it) },
                        onSaveVideo = { viewModel.exportVideo() },
                        onSaveToDownloads = { viewModel.exportAudio(saveToMusic = false) },
                        onSaveToMusic = { viewModel.exportAudio(saveToMusic = true) },
                        onShareVideo = { viewModel.shareMedia(isVideo = true) },
                        onShareAudio = { viewModel.shareMedia(isVideo = false) }
                    )
                }
            }

            // Optional Advanced Tuning Accordion
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { showAdvancedSettings = !showAdvancedSettings },
                colors = CardDefaults.cardColors(containerColor = StudioCardBg)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = null,
                                tint = TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "सुरक्षा विवरण (YouTube Shorts & Music Protection)",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = TextSecondary
                            )
                        }
                        Icon(
                            imageVector = if (showAdvancedSettings) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null,
                            tint = TextSecondary
                        )
                    }

                    if (showAdvancedSettings) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "• YouTube Shorts वीडियो में वीडियो फ्रेम बिना किसी नुक़सान के (-c:v copy) रहते हैं और ऑडियो ट्रैक को सेफ DSP लेयर मिल जाती है।\n" +
                                    "• 6ms स्टीरियो फेज़ डिले (Stereo Phase Shift)\n" +
                                    "• +1.0dB सब-बेस व +1.2dB एयर ट्रेबल (गायक की आवाज़ 100% साफ़)\n" +
                                    "• -38dB सूक्ष्म इनऑडिबल एम्बिएंट शील्ड (Content ID हैश ब्रेक)\n" +
                                    "• -14 LUFS यूट्यूब स्टैंडर्ड लाउडनेस नॉर्मलाइज़ेशन\n" +
                                    "• सारे आईडी टैग्स व मेटाडेटा ऑटोमैटिक हटाए जाते हैं।",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyanSecondary,
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            // Error Display if Failed
            if (processingState is ProcessingState.Error) {
                val error = processingState as ProcessingState.Error
                Card(
                    colors = CardDefaults.cardColors(containerColor = StudioCardBg),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, AccentError.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = AccentError)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("समस्या आई", fontWeight = FontWeight.Bold, color = AccentError)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(error.message, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun EasySongInputCard(
    selectedAudio: AudioFileInfo?,
    onSelectAudioClick: () -> Unit,
    onSelectVideoClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.5.dp,
                if (selectedAudio != null) EmeraldTertiary.copy(alpha = 0.8f) else CyanPrimary.copy(alpha = 0.4f),
                RoundedCornerShape(16.dp)
            ),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = StudioCardBg)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (selectedAudio == null) {
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(CyanPrimary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Audiotrack,
                            contentDescription = null,
                            tint = CyanPrimary,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(EmeraldTertiary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.VideoLibrary,
                            contentDescription = null,
                            tint = EmeraldTertiary,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "स्टेप 1: गाना या YouTube Short वीडियो चुनें",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "गाना (MP3/WAV) चुनें या सीधे YouTube Shorts/Reels वीडियो (MP4) चुनें:",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Dual Selection Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onSelectAudioClick,
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("select_song_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.MusicNote, contentDescription = null, tint = StudioDarkBg, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "गाना (Audio)",
                            color = StudioDarkBg,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    Button(
                        onClick = onSelectVideoClick,
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("select_video_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldTertiary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Movie, contentDescription = null, tint = StudioDarkBg, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Shorts वीडियो",
                            color = StudioDarkBg,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Brush.linearGradient(listOf(EmeraldTertiary, CyanPrimary))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (selectedAudio.isVideo) Icons.Default.Movie else Icons.Default.MusicNote,
                            contentDescription = null,
                            tint = StudioDarkBg,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(EmeraldTertiary.copy(alpha = 0.2f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (selectedAudio.isVideo) "VIDEO (${selectedAudio.extension})" else selectedAudio.extension,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldTertiary
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = selectedAudio.name,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "साइज़: ${selectedAudio.formattedSize} • अवधि: ${selectedAudio.formattedDuration}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onSelectAudioClick,
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CyanPrimary)
                    ) {
                        Text("गाना बदलें", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = onSelectVideoClick,
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = EmeraldTertiary)
                    ) {
                        Text("Shorts वीडियो बदलें", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun OneClickProcessCard(
    selectedAudio: AudioFileInfo?,
    processingState: ProcessingState,
    onStartProcessing: () -> Unit
) {
    val isProcessing = processingState is ProcessingState.Processing
    val isSuccess = processingState is ProcessingState.Success
    val isVideo = selectedAudio?.isVideo == true

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, StudioSurfaceVariant, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = StudioCardBg)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "स्टेप 2: 1-क्लिक कॉपीराइट सेफ शील्ड",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (isVideo) {
                    "YouTube Shorts वीडियो का ऑडियो वेवफ़ॉर्म व डिजिटल फ़िंगरप्रिंट सुरक्षित किया जाएगा ताकि कॉपीराइट स्ट्राइक या क्लेम न आए।"
                } else {
                    "गाने का वेवफ़ॉर्म व डिजिटल फ़िंगरप्रिंट सुरक्षित होगा, और सुनने में 100% ओरिजिनल आवाज़ व मिठास बरकरार रहेगी।"
                },
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                textAlign = TextAlign.Center,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onStartProcessing,
                enabled = selectedAudio != null && !isProcessing,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("apply_mod_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = EmeraldTertiary,
                    disabledContainerColor = StudioSurfaceVariant
                )
            ) {
                if (isProcessing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = StudioDarkBg,
                        strokeWidth = 2.5.dp
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "प्रोसेसिंग जारी है...",
                        color = StudioDarkBg,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = if (selectedAudio != null) StudioDarkBg else TextSecondary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = if (isSuccess) {
                            "दोबारा प्रोसेस करें / Re-Process"
                        } else if (isVideo) {
                            "Shorts वीडियो को सुरक्षित करें (Start)"
                        } else {
                            "कॉपीराइट से सुरक्षित करें (Start)"
                        },
                        color = if (selectedAudio != null) StudioDarkBg else TextSecondary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            }

            // Real-Time Progress Bar with Live %
            if (isProcessing) {
                val proc = processingState as ProcessingState.Processing
                Spacer(modifier = Modifier.height(16.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(StudioDarkBg)
                        .padding(14.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isVideo) "YouTube Shorts वीडियो सुरक्षित हो रहा है..." else "ऑडियो वेवफ़ॉर्म बदल रहा है...",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "${proc.progressPercentage}%",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = CyanPrimary
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        LinearProgressIndicator(
                            progress = { proc.progressPercentage / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = CyanPrimary,
                            trackColor = StudioSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = proc.stageMessage,
                            style = MaterialTheme.typography.labelSmall,
                            color = CyanSecondary,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun EasyReadyExportCard(
    success: ProcessingState.Success,
    playerState: PlayerState,
    onPlayPause: () -> Unit,
    onSeek: (Int) -> Unit,
    onSwitchTrack: (AudioTrackType) -> Unit,
    onSaveVideo: () -> Unit,
    onSaveToDownloads: () -> Unit,
    onSaveToMusic: () -> Unit,
    onShareVideo: () -> Unit,
    onShareAudio: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("audio_player_card")
            .border(2.dp, EmeraldTertiary, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = StudioCardBg)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Big Green Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(EmeraldTertiary.copy(alpha = 0.15f))
                    .border(1.dp, EmeraldTertiary.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Success",
                        tint = EmeraldTertiary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = if (success.isVideo) "स्टेप 3: YouTube Short पूरी तरह तैयार है!" else "स्टेप 3: गाना पूरी तरह रेडी है!",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldTertiary
                        )
                        Text(
                            text = "अब इसे YouTube, Instagram, Facebook पर बिना स्ट्राइक के अपलोड करें!",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextPrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Export Section
            if (success.isVideo && success.outputVideoFile != null) {
                Text(
                    text = "🎬 YouTube Short वीडियो सेव करें:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onSaveVideo,
                        modifier = Modifier
                            .weight(1.2f)
                            .height(50.dp)
                            .testTag("save_video_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldTertiary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = null, tint = StudioDarkBg, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Gallery में सेव करें", color = StudioDarkBg, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    Button(
                        onClick = onShareVideo,
                        modifier = Modifier
                            .weight(0.9f)
                            .height(50.dp)
                            .testTag("share_video_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, tint = StudioDarkBg, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("YouTube/Reels", color = StudioDarkBg, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
            }

            // Audio Export Options
            Text(
                text = if (success.isVideo) "🎵 केवल ऑडियो ट्रैक (MP3) सेव करें:" else "सीधे सेव करें (Save to Phone):",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onSaveToDownloads,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("save_downloads_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = if (success.isVideo) StudioSurfaceVariant else EmeraldTertiary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Download, contentDescription = null, tint = if (success.isVideo) TextPrimary else StudioDarkBg, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Downloads फ़ोल्डर", color = if (success.isVideo) TextPrimary else StudioDarkBg, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                Button(
                    onClick = onSaveToMusic,
                    modifier = Modifier
                        .weight(0.9f)
                        .height(48.dp)
                        .testTag("save_music_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.LibraryMusic, contentDescription = null, tint = StudioDarkBg, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Music फ़ोल्डर", color = StudioDarkBg, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                if (!success.isVideo) {
                    Button(
                        onClick = onShareAudio,
                        modifier = Modifier
                            .weight(0.8f)
                            .height(48.dp)
                            .testTag("share_audio_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = StudioSurfaceVariant),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, tint = CyanPrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Share", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // In-Built A/B Audio Player
            Text(
                text = "सुनकर देखें (क्वालिटी व मिठास 100% बरकरार है):",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Switch between Modified vs Original
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(StudioDarkBg)
                    .padding(4.dp)
            ) {
                val isModSelected = playerState.currentTrack == AudioTrackType.MODIFIED
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isModSelected) CyanPrimary else Color.Transparent)
                        .clickable { onSwitchTrack(AudioTrackType.MODIFIED) }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = if (isModSelected) StudioDarkBg else TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "🛡️ सेफ ट्रैक",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isModSelected) StudioDarkBg else TextSecondary
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (!isModSelected) CyanPrimary else Color.Transparent)
                        .clickable { onSwitchTrack(AudioTrackType.ORIGINAL) }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = null,
                            tint = if (!isModSelected) StudioDarkBg else TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "🎵 ओरिजिनल",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (!isModSelected) StudioDarkBg else TextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Waveform animation
            EasyWaveformBars(isPlaying = playerState.isPlaying)

            Spacer(modifier = Modifier.height(10.dp))

            // Seek slider
            val duration = playerState.durationMs.coerceAtLeast(1)
            val currentPos = playerState.currentPositionMs.coerceIn(0, duration)

            Slider(
                value = currentPos.toFloat(),
                onValueChange = { onSeek(it.toInt()) },
                valueRange = 0f..duration.toFloat(),
                modifier = Modifier.fillMaxWidth(),
                colors = SliderDefaults.colors(
                    thumbColor = CyanPrimary,
                    activeTrackColor = CyanPrimary,
                    inactiveTrackColor = StudioSurfaceVariant
                )
            )

            // Timestamps
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = StorageHelper.formatDuration(currentPos.toLong()),
                    style = MaterialTheme.typography.labelSmall,
                    color = CyanSecondary
                )
                Text(
                    text = StorageHelper.formatDuration(duration.toLong()),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Play / Pause Button
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                IconButton(
                    onClick = onPlayPause,
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(CyanPrimary, EmeraldTertiary)))
                        .testTag("play_pause_button")
                ) {
                    Icon(
                        imageVector = if (playerState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (playerState.isPlaying) "Pause" else "Play",
                        tint = StudioDarkBg,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun EasyWaveformBars(isPlaying: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "easyWaveAnim")

    val bar1 by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(tween(320), RepeatMode.Reverse),
        label = "ew1"
    )
    val bar2 by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(tween(260), RepeatMode.Reverse),
        label = "ew2"
    )
    val bar3 by infiniteTransition.animateFloat(
        initialValue = 0.15f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(tween(410), RepeatMode.Reverse),
        label = "ew3"
    )
    val bar4 by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.92f,
        animationSpec = infiniteRepeatable(tween(300), RepeatMode.Reverse),
        label = "ew4"
    )
    val bar5 by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 0.82f,
        animationSpec = infiniteRepeatable(tween(370), RepeatMode.Reverse),
        label = "ew5"
    )

    val barScales = listOf(bar1, bar2, bar3, bar4, bar5, bar3, bar2, bar4, bar1, bar5, bar2, bar3, bar1, bar4, bar2)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(34.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(StudioDarkBg)
            .padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        barScales.forEachIndexed { index, scale ->
            val activeHeight = if (isPlaying) (scale * 22).dp.coerceAtLeast(4.dp) else 4.dp
            val color = if (index % 2 == 0) CyanPrimary else EmeraldTertiary
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(activeHeight)
                    .clip(RoundedCornerShape(2.dp))
                    .background(color)
            )
        }
    }
}
