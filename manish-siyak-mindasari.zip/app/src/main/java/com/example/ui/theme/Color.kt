package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyanPrimary = Color(0xFF00E5FF)
val CyanSecondary = Color(0xFF1DE9B6)
val EmeraldTertiary = Color(0xFF00E676)

val StudioDarkBg = Color(0xFF0B1120)
val StudioCardBg = Color(0xFF131F37)
val StudioSurfaceVariant = Color(0xFF1E2D4E)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val AccentWarning = Color(0xFFFFB020)
val AccentSuccess = Color(0xFF10B981)
val AccentError = Color(0xFFEF4444)

val Purple80 = CyanPrimary
val PurpleGrey80 = CyanSecondary
val Pink80 = EmeraldTertiary

val Purple40 = Color(0xFF0284C7)
val PurpleGrey40 = Color(0xFF0D9488)
val Pink40 = Color(0xFF059669)

